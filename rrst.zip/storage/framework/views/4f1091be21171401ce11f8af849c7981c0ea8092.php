

<?php $__env->startSection('content'); ?>
<header class="header header--page header--fixed">	
    <div class="header__inner">	
        <div class="header__icon header__icon--menu open-panel" data-panel="left" data-arrow="right"><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
        <div class="header__logo header__logo--text"><a href="#"><strong>BKK</strong>Mobile</a></div>	
        <div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://gomobile.website/assets/images/icons/white/user.svg" alt="" title=""/></div>
            </div>
</header>

<!-- PAGE CONTENT -->
<div class="page__content page__content--with-header">
    <h2 class="page__title">Custom Forms & Inputs</h2>  
    <div class="fieldset">
        <div class="form">
            <form id="Form" method="post" action="https://gomobile.website/demos/forms.html">
                <div class="form__row">
                    <input type="text" name="Text" value="" class="form__input required" placeholder="Text" />
                </div>
                <div class="form__row d-flex align-items-center justify-space">
                    <input type="text" name="Text" value="" class="form__input form__input--12" placeholder="Text 1/2" />
                    <input type="text" name="Text" value="" class="form__input form__input--12" placeholder="Text 1/2" />
                </div>
                <div class="form__row d-flex align-items-center justify-space">
                    <input type="text" name="Text" value="" class="form__input form__input--23" placeholder="Text 2/3" />
                    <input type="text" name="Text" value="" class="form__input form__input--13" placeholder="Text 1/3" />
                </div>
                <div class="form__row">
                    <input type="text" name="Email" value="" class="form__input email required" placeholder="Email" />
                </div>
                <div class="form__row">
                    <input type="number" name="Number" value="" class="form__input required" placeholder="Number" />
                </div>
                <div class="form__row">
                    <input type="date" name="Date" value="" class="form__input required" placeholder="Date" />
                </div>
                <div class="form__row">
                    <div class="form__select">
                        <select name="selectoptions" class="required">
                            <option value="" disabled selected>Select options</option>
                            <option value="1">select one</option>
                            <option value="2">select two</option>
                            <option value="3">select three</option>
                            <option value="4">select four</option>
                            <option value="5">select five</option>
                        </select>
                    </div>
                </div>
                <div class="form__row">
                    <textarea name="TextArea" class="form__textarea required" placeholder="TextArea"></textarea>
                </div>	
                
                <h3 class="pb-20 pt-20">Custom radio inputs</h3>
                <div class="radio-option radio-option--full">
                    <input type="radio" name="radioption" id="op1" value="1" checked /><label for="op1">Radio input <span>01</span></label>
                </div>
                <div class="radio-option radio-option--full">
                    <input type="radio" name="radioption" id="op2" value="2" /><label for="op2">Radio input <span>02</span></label>
                </div>
                <div class="radio-option radio-option--full">
                    <input type="radio" name="radioption" id="op3" value="3" /><label for="op3">Radio input <span>03</span></label>
                </div>
                
                <h3 class="pb-20 pt-20">Custom radio inputs style 2</h3>
                <div class="radio-option">
                    <input type="radio" name="radioption1" id="op4" value="1" checked /><label for="op4">01</label>
                </div>
                <div class="radio-option">
                    <input type="radio" name="radioption1" id="op5" value="2" /><label for="op5">02</label>
                </div>
                <div class="radio-option">
                    <input type="radio" name="radioption1" id="op6" value="3" /><label for="op6">03</label>
                </div>
                <div class="radio-option">
                    <input type="radio" name="radioption1" id="op7" value="4" /><label for="op7">04</label>
                </div>	
                
                <h3 class="pb-20 pt-20">Custom checkbox inputs</h3>
                <div class="checkbox-option checkbox-option--full">
                    <input type="checkbox" name="checkboxoption1" id="cp1" value="1" checked /><label for="cp1">Checkbox input <span>01</span></label>
                </div>
                <div class="checkbox-option checkbox-option--full">
                    <input type="checkbox" name="checkboxoption2" id="cp2" value="2" /><label for="cp2">Checkbox input <span>02</span></label>
                </div>
                <div class="checkbox-option checkbox-option--full">
                    <input type="checkbox" name="checkboxoption3" id="cp3" value="3" /><label for="cp3">Checkbox input <span>03</span></label>
                </div>
                
                <h3 class="pb-20 pt-20">Custom checkbox style 2</h3>
                <div class="checkbox-option">
                    <input type="checkbox" name="checkboxoption1" id="cp4" value="1" checked /><label for="cp4">01</label>
                </div>
                <div class="checkbox-option">
                    <input type="checkbox" name="checkboxoption2" id="cp5" value="2" /><label for="cp5">02</label>
                </div>
                <div class="checkbox-option">
                    <input type="checkbox" name="checkboxoption3" id="cp6" value="3" /><label for="cp6">03</label>
                </div>
                <div class="checkbox-option">
                    <input type="checkbox" name="checkboxoption3" id="cp7" value="3" /><label for="cp7">04</label>
                </div>		
                <h3 class="pb-20 pt-20">Custom switch input</h3>
                <div class="form__row">  
                    <div class="switch">
                        <label>Enable:</label>
                        <input type="checkbox" hidden="hidden" id="enable">
                        <label class="switch__label" for="enable"></label>
                    </div>
                </div>
                <h3 class="pb-20 pt-20">Simple agree checkbox</h3>
                <div class="form__row">
                    <div class="checkbox-simple">
                        <input type="checkbox" name="agree" id="agree" value="agree" checked /><label for="agree">Agree Terms &amp; Conditions</span></label>
                    </div>
                </div>
                <div class="form__row mt-40">
                    <input type="submit" name="submit" class="form__submit button button--green button--full" id="submit" value="SUBMIT" />
                </div>
            </form>
        </div>
    </div>


        
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkk\resources\views/frontend/update_profil.blade.php ENDPATH**/ ?>
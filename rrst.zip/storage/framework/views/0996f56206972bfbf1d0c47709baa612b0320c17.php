

<?php $__env->startSection('content'); ?>
	
	<!-- HEADER -->
	<header class="header header--page header--fixed">	
		<div class="header__inner">	
			<div class="header__icon header__icon--menu open-panel" data-panel="left" data-arrow="right"><span></span><span></span><span></span><span></span><span></span><span></span></a></div>
			<div class="header__logo header__logo--text"><a href="#"><strong>BKK</strong>Mobile</a></div>	
			<div class="header__icon open-panel" data-panel="right" data-arrow="left"><img src="https://gomobile.website/assets/images/icons/white/user.svg" alt="" title=""/></div>
                </div>
	</header>
	
	<!-- PAGE CONTENT -->
	<div class="page__content page__content--with-header">

		<h2 class="page__title">Lowongan Kerja Terbaru</h2>

              <div class="posts">
			  <div class="post">
				  <div class="post__thumb">
					  <a href="blog-single.html"><img src="<?php echo e(asset ('go/assets/images/photos/image-1.jpg')); ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="blog-single.html">Creativity is allowing yourself to make mistakes</a></h4>
					<a href="blog-single.html" class="post__more button button--blue button--ex-small">READ IT</a>
				  </div>
			  </div>
			  <div class="post">
				  <div class="post__thumb">
					  <a href="blog-single.html"><img src="<?php echo e(asset ('go/assets/images/photos/image-2.jpg')); ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="blog-single.html">The true sign of intelligence is not not knowledge</a></h4>
					<a href="blog-single.html" class="post__more button button--blue button--ex-small">READ IT</a>
				  </div>
			  </div>
			  <div class="post">
				  <div class="post__thumb">
					  <a href="blog-single.html"><img src="<?php echo e(asset ('go/assets/images/photos/image-3.jpg')); ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="blog-single.html">The desire to create is one of the deepest yearnings</a></h4>
					<a href="blog-single.html" class="post__more button button--blue button--ex-small">READ IT</a>
				  </div>
			  </div>
			  <div class="post">
				  <div class="post__thumb">
					  <a href="blog-single.html"><img src="<?php echo e(asset ('go/assets/images/photos/image-4.jpg')); ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="blog-single.html">Creativity is breaking out of  patterns</a></h4>
					<a href="blog-single.html" class="post__more button button--blue button--ex-small">READ IT</a>
				  </div>
			  </div>
			  <div class="post">
				  <div class="post__thumb">
					  <a href="blog-single.html"><img src="<?php echo e(asset ('go/assets/images/photos/image-5.jpg')); ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="blog-single.html">An idea that is not dangerous is unworthy</a></h4>
					<a href="blog-single.html" class="post__more button button--blue button--ex-small">READ IT</a>
				  </div>
			  </div> 
			  <div class="post">
				  <div class="post__thumb">
					  <a href="blog-single.html"><img src="<?php echo e(asset ('go/assets/images/photos/image-6.jpg')); ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="blog-single.html">Creativity is allowing yourself to make mistakes</a></h4>
					<a href="blog-single.html" class="post__more button button--blue button--ex-small">READ IT</a>
				  </div>
			  </div>
			  <div class="post">
				  <div class="post__thumb">
					  <a href="blog-single.html"><img src="<?php echo e(asset ('go/assets/images/photos/image-7.jpg')); ?>" alt="" title=""/></a>
				  </div>
				  <div class="post__details">
					<h4 class="post__title"><a href="blog-single.html">The true sign of intelligence is not not knowledge</a></h4>
					<a href="blog-single.html" class="post__more button button--blue button--ex-small">READ IT</a>
				  </div>
			  </div>
              </div>
	
	</div>
			  




<!-- PAGE END -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkk\resources\views/frontend/info_loker.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
 <!-- Begin Page Content -->
 <div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Job Vacancy</h1>
    <a onClick="window.location.reload();" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
            class="fas fa-reload fa-sm text-white-50"></i> Resfresh</a>
</div>

<div class="row">

    <!-- Earnings (Monthly) Card Example -->
    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                           <?php echo e($job->title_jobs); ?></div>
                            <div class="btn-group">
                                <a href="<?php echo e(url ('edit_jobs/'.$job->id)); ?>" class=" btn btn-warning btn-sm form-control">Edit</a>
                                <a href="<?php echo e(url ('delete_jobs/'.$job->id)); ?>" class=" btn btn-danger btn-sm form-control">Hapus</a>
                            </div>
                            <div class="float-right">
                                <a href="<?php echo e(url ('view_peserta/'.$job->id)); ?>" class=" btn-sm btn btn-secondary">Lihat Peserta</a>
                            </div>
                    </div>
                    <!-- <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkk\resources\views/component_backend/content/index_a_jobs.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
 <!-- Begin Page Content -->
 <div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Peserta | <small><b><?php echo e($db_jobs->title_jobs); ?></b></small></h1>
        <a onClick="window.location.reload();" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-refresh fa-sm text-white-50"></i> Resfresh</a>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body " style="overflow-x:auto;">
                <table class="table table-bordered" id="table_view_peserta">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th>No</th>
                            <th>Nama _Peserta</th>
                            <th>Tempat_Tanggal_Lahir</th>
                            <th>Nomer_Wa</th>
                            <th>Email</th>
                            <th>Pendidikan</th>
                            <th>Alamat</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $view_peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$vp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($vp->relation_user->full_name); ?></td>
                            <td><?php echo e($vp->relation_user->place); ?> ,<?php echo e(date('d M Y',strtotime($vp->relation_user->date_of_birth))); ?></td>
                            <td><?php echo e($vp->relation_user->number_phone); ?></td>
                            <td><?php echo e($vp->relation_user->relation_user2->email); ?></td>
                            <td><?php echo e($vp->relation_user->last_education); ?></td>
                            <td><?php echo $vp->relation_user->address; ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">


  $(document).ready(function() {
    $('#table_view_peserta').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', {
                extend: 'excelHtml5',
                title: 'Data Peserta'
            }, {
                extend: 'pdfHtml5',
                title: 'Data Peserta'
            }, 'print'
        ]
    } );
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkk\resources\views/component_backend/content/view_peserta.blade.php ENDPATH**/ ?>
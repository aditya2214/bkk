<div class="appBottomMenu">
    <a href="<?php echo e(url ('/')); ?>" class="item active">
        <div class="col">
        <i class="fas fa-home fa-3x"></i>
        <br>
        <b>Home</b>
    </div>
    </a>
    <a href="<?php echo e(url ('media_bkk')); ?>" class="item">
        <div class="col">
        <i class="fas fa-photo-video fa-3x"></i>
        <br>
        <b>Media BKK</b>
        </div>
    </a>
    <a href="<?php echo e(url ('chat')); ?>"" class="item">
        <div class="col">
        <i class="far fa-comments fa-3x"></i>
            <span class="badge badge-danger">5</span>
            <br>
            <b>Chat</b>
        </div>
    </a>
    <?php if(Auth::user() != null): ?>
    <a href="<?php echo e(url ('page_profil_user')); ?>" class="item">
        <div class="col">
        <i class="fas fa-user-tag fa-3x"></i>
        <br>
        <b><?php echo e(Auth::user()->email); ?></b>
    </div>
    </a>
    <?php else: ?>
    <a href="<?php echo e(url ('login')); ?>" class="item">
        <div class="col">
        <i class="fas fa-user-tag fa-3x"></i>
        <br>
        <b>Login</b>
    </div>
    </a>
    <?php endif; ?>
    <a href="#" class="item" data-toggle="modal" data-target="#sidebarPanel">
        <div class="col">
        <i class="fas fa-cog fa-3x"></i>
        <br>
        <b>Pengaturan</b>
        </div>
    </a>
</div><?php /**PATH C:\xampp\htdocs\bkk\resources\views/button_bottom.blade.php ENDPATH**/ ?>
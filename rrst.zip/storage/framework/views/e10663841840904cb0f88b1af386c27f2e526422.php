

<?php $__env->startSection('content'); ?>
<div class="section full mt-3 mb-3">
    <div class="carousel-multiple owl-carousel owl-theme">

        <div class="item">
            <div class="card">
                <img src="<?php echo e(asset ('cv6.png')); ?>" class="card-img-top" alt="image">
                <div class="card-body pt-2">
                    <h4 class="mb-0">CV6</h4>
                    <p class="text-warning"></i>&nbsp; Rp 20.000</p>
                    
                </div>

            </div>
        </div>

        <div class="item">
            <div class="card">
                <img src="<?php echo e(asset ('cv1.jfif')); ?>" class="card-img-top" alt="image">
                <div class="card-body pt-2">
                    <h4 class="mb-0">CV1</h4>
                    <p class="text-warning"></i>&nbsp; Rp 20.000</p>
                    
                </div>

            </div>
        </div>

        <div class="item">
            <div class="card">
                <img src="<?php echo e(asset ('cv2.jfif')); ?>" class="card-img-top" alt="image">
                <div class="card-body pt-2">
                    <h4 class="mb-0">CV1</h4>
                    <p class="text-warning"></i>&nbsp; Rp 20.000</p>
                    
                </div>

            </div>
        </div>

        <div class="item">
            <div class="card">
                <img src="<?php echo e(asset ('cv3.jfif')); ?>" class="card-img-top" alt="image">
                <div class="card-body pt-2">
                    <h4 class="mb-0">CV1</h4>
                    <p class="text-warning"></i>&nbsp; Rp 20.000</p>
                    
                </div>

            </div>
        </div>

        <div class="item">
            <div class="card">
                <img src="<?php echo e(asset ('cv4.jfif')); ?>" class="card-img-top" alt="image">
                <div class="card-body pt-2">
                    <h4 class="mb-0">CV1</h4>
                    <p class="text-warning"></i>&nbsp; Rp 20.000</p>
                    
                </div>

            </div>
        </div>

        <div class="item">
            <div class="card">
                <img src="<?php echo e(asset ('cv5.jfif')); ?>" class="card-img-top" alt="image">
                <div class="card-body pt-2">
                    <h4 class="mb-0">CV1</h4>
                    <p class="text-warning"></i>&nbsp; Rp 20.000</p>
                    
                </div>

            </div>
        </div>
    </div>
</div>

<hr>
&nbsp;&nbsp;&nbsp;&nbsp;<b>LOWONGAN TERSEDIA</b>
<hr>

<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="section mt-3 mb-3">
    <div class="card">
        <div class="form-row">
            <div class="col-4">
                <img src="<?php echo e(asset ('download.png')); ?>" class="card-img-top" alt="image">
            </div>
            <div class="col-8">
                <div class="card-body">
                    <h6 class="card-subtitle"><?php echo e($job->title_jobs); ?></h6>
                    <!-- <p>Tanggal Tes : <?php echo e(date('D, d M Y',strtotime($job->test_date))); ?></p> -->
                    <p class="card-text">
                        <?php echo e($job->education); ?>

                    </p>
                    <a href="<?php echo e(url ('pageDetailJob/'.$job->id_jobs)); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-eye"></i>&nbsp;
                        Detail
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bkk\resources\views/content_frontend/loker.blade.php ENDPATH**/ ?>
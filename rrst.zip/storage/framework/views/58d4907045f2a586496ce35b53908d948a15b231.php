

<div class="modal fade panelbox panelbox-left" id="sidebarPanel" tabindex="-1" role="dialog">

    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">

                <!-- profile box -->
                <?php if(Auth::user() == null): ?>
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4"><b>LOGIN</b></h1>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <input placeholder="Email" id="email" type="email" class="form-control form-control-user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <input placeholder="Password" id="password" type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                                <label class="form-check-label" for="remember">
                                                    <?php echo e(__('Remember Me')); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-user btn-block">
                                            <?php echo e(__('Login')); ?>

                                        </button>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="<?php echo e(url ('register')); ?>">Create an Account!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="profileBox">
                    <div class="image-wrapper">
                        <?php if($profil_user == null): ?>
                        <img src="" alt="image" class="imaged rounded">
                        <?php else: ?>
                        <img src="<?php echo e(asset ('storage/'.$profil_user->images)); ?>" alt="image" class="imaged rounded">
                        <?php endif; ?>
                    </div>
                    <div class="in">
                        <strong><?php echo e(Auth::user()->name); ?></strong>
                        <div class="text-muted">
                            <ion-icon name="location"></ion-icon>
                            <?php echo e(Auth::user()->email); ?>

                        </div>
                    </div>
                    <a href="javascript:;" class="close-sidebar-button" data-dismiss="modal">
                        <ion-icon name="close"></ion-icon>
                    </a>
                </div>
                <!-- * profile box -->

                <ul class="listview flush transparent no-line image-listview mt-2">
                    <li>
                        <a href="<?php echo e(url ('page_profil_user')); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Profile
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="app-components.html" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="cube-outline"></ion-icon>
                            </div>
                            <div class="in">
                               Notification
                            </div>
                            <span class="badge badge-danger">5</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url ('home')); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="layers-outline"></ion-icon>
                            </div>
                            <div class="in">
                                <div>Lowongan Pekerjaan</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="page-chat.html" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="chatbubble-ellipses-outline"></ion-icon>
                            </div>
                            <div class="in">
                                <div>Buat CV</div>
                                
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url ('logout')); ?>" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="chatbubble-ellipses-outline"></ion-icon>
                            </div>
                            <div class="in">
                                <div>Logout</div>
                                
                            </div>
                        </a>
                    </li>
                    <li>
                        <div class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="moon-outline"></ion-icon>
                            </div>
                            <div class="in">
                                <div>Dark Mode</div>
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input dark-mode-switch"
                                        id="darkmodesidebar">
                                    <label class="custom-control-label" for="darkmodesidebar"></label>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>

                <!-- <div class="listview-title mt-2 mb-1">
                    <span>Friends</span>
                </div>
                <ul class="listview image-listview flush transparent no-line">
                    <li>
                        <a href="page-chat.html" class="item">
                            <img src="<?php echo e(asset ('frontend/assets/img/sample/avatar/avatar7.jpg')); ?>" alt="image" class="image">
                            <div class="in">
                                <div>Sophie Asveld</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="page-chat.html" class="item">
                            <img src="<?php echo e(asset ('frontend/assets/img/sample/avatar/avatar3.jpg')); ?>" alt="image" class="image">
                            <div class="in">
                                <div>Sebastian Bennett</div>
                                <span class="badge badge-danger">6</span>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="page-chat.html" class="item">
                            <img src="<?php echo e(asset ('frontend/assets/img/sample/avatar/avatar10.jpg')); ?>" alt="image" class="image">
                            <div class="in">
                                <div>Beth Murphy</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="page-chat.html" class="item">
                            <img src="<?php echo e(asset ('frontend/assets/img/sample/avatar/avatar2.jpg')); ?>" alt="image" class="image">
                            <div class="in">
                                <div>Amelia Cabal</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="page-chat.html" class="item">
                            <img src="<?php echo e(asset ('frontend/assets/img/sample/avatar/avatar5.jpg')); ?>" alt="image" class="image">
                            <div class="in">
                                <div>Henry Doe</div>
                            </div>
                        </a>
                    </li>
                </ul> -->
                <?php endif; ?>

            </div>

            <!-- sidebar buttons -->
            <!-- <div class="sidebar-buttons">
                <a href="javascript:;" class="button">
                    <ion-icon name="person-outline"></ion-icon>
                </a>
                <a href="javascript:;" class="button">
                    <ion-icon name="archive-outline"></ion-icon>
                </a>
                <a href="javascript:;" class="button">
                    <ion-icon name="settings-outline"></ion-icon>
                </a>
                <a href="javascript:;" class="button">
                    <ion-icon name="log-out-outline"></ion-icon>
                </a>
            </div> -->
            <!-- * sidebar buttons -->
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\bkk\resources\views/sidebar.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from gomobile.website/demos/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 May 2021 19:57:19 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, minimal-ui">
<title>GoMobile - Premium Mobile Template</title>
<link rel="stylesheet" href="<?php echo e(asset ('go/vendor/swiper/swiper.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('go/demos/css/style.css')); ?>">
<link rel="preconnect" href="https://fonts.gstatic.com/">
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet"> 
<link href="<?php echo e(asset ('css/sb-admin-2.min.css')); ?>" rel="stylesheet">
</head>
<body>
	
    <?php echo $__env->yieldContent('content'); ?>;	
    
    <div id="bottom-toolbar" class="bottom-toolbar">
        <button class="caption__more button button--small button--blue">INFO LOKER</button>
    </div>


<script src="<?php echo e(asset ('go/vendor/jquery/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset ('go/vendor/jquery/jquery.validate.min.js')); ?>" ></script>
<script src="<?php echo e(asset ('go/vendor/swiper/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset ('go/demos/js/jquery.custom.js')); ?>"></script>
</body>

<!-- Mirrored from gomobile.website/demos/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 May 2021 19:57:23 GMT -->
</html><?php /**PATH C:\xampp\htdocs\bkk\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>